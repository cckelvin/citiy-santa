// Load default products from products.json (not included in this example for simplicity)
let defaultProducts = [];

fetch('products.json')
  .then(res => res.json())
  .then(data => {
    defaultProducts = data;
    displayProducts();
});

// Load products from localStorage and Firebase, then display them
function displayProducts() {
  const saved = JSON.parse(localStorage.getItem('products') || '[]');
  const container = document.getElementById('product-list');
  const allProducts = [...defaultProducts, ...saved];

  allProducts.forEach(product => {
    container.innerHTML += `
      <div class="product">
        <img src="${product.image}" alt="${product.name}" />
        <h3>${product.name}</h3>
        <p>${product.price}</p>
        <button onclick="alert('Purchase Complete!')">Buy Now</button>
      </div>
    `;
  });
}